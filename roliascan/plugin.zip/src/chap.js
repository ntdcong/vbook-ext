load('config.js');

function execute(url) {
    // Chuẩn hóa URL về BASE_URL nếu có tên miền khác
    url = url.replace(/^(?:https?:\/\/)?(?:www\.)?([^/]+)(\/.+)/i, BASE_URL + "$2");

    let response = fetch(url);
    if (!response.ok) return null;

    let doc = response.html();

    let imgs = [];

    // Lấy tất cả thẻ <img> trong phần nội dung chương
    doc.select(".manga-child-the-content img").forEach(e => {
        let img = e.attr("src");

        if (!img) return;

        img = img.trim();

        // Bỏ qua ảnh quảng cáo/cảnh báo không cần thiết
        if (
            img.includes("warning") ||
            img.includes("discord") ||
            img.includes("x99") ||
            img.includes("donate") ||
            img.includes("creblogtruyen")
        ) {
            return;
        }

        // Chuẩn hóa URL ảnh
        if (img.startsWith("//")) {
            img = "https:" + img;
        } else if (img.startsWith("/")) {
            img = BASE_URL + img;
        }

        imgs.push(img);
    });

    return Response.success(imgs);
}
